import { Link } from 'react-router-dom';

import { useState, useEffect } from 'react';
function Content({deals, image, cards}){
  const [slide2, setSlide2] = useState();
  const [card, setCard] = useState();
  const [slide3, setSlide3] = useState();


    function  Left(){
      document.querySelector('.contentcontainer').scrollLeft -= 100;
    
      }
      function  Right(){
        document.querySelector('.contentcontainer').scrollLeft += 100;
    
      }
      function  Left1(){
       
    
        document.querySelector('.contentcontainer1').scrollLeft -= 100;

      
        }
        function  Right1(){
          
          document.querySelector('.contentcontainer1').scrollLeft += 100;
      
        }
        function  Left2(){
          document.querySelector('.contentcontainer2').scrollLeft -= 100;
        
          }
          function  Right2(){
            document.querySelector('.contentcontainer2').scrollLeft += 100;
        
          }
      
useEffect(()=>{
 
  fetch('https://fakestoreapi.com/products?limit=10')
  .then(res=>res.json())
  .then((data)=>{
    setSlide2(data);
   
  })
  fetch('https://api.escuelajs.co/api/v1/products?offset=0&limit=10')
  .then(res=>res.json())
  .then((data)=>{
    console.log(data)
    setCard(data);
   
  })
  fetch('https://api.escuelajs.co/api/v1/products?offset=10&limit=20')
  .then(res=>res.json())
  .then((data)=>{
    console.log(data)
    setSlide3(data);
   
  })

},[])

    return(
        <>
            
      <div className='content-container   mt-40 bg-white  p-3'>
      <h1 className='text-xl font-bold'>Today Deals</h1>
      <button className=' absolute  mt-16 h-12 border w-8 bg-white' onClick={Left} >
        <i className='fa fa-chevron-left  text-lg'></i>
      </button>
      <button className=' absolute mt-16  btn1  border' onClick={Right} >
        <i className='fa fa-chevron-right  text-lg'></i>
      </button>
      <div className='contentcontainer overflow-x-auto flex  mt-3'>
   {deals?  deals.map((item)=>(
      <div className=' w-52 ml-9' key = {item.id}>
      <div className='contentcards border   w-48  grid justify-center bg-gray-100'>
      <Link to = "/ShowProduct">  <img src = {item.image} alt = "..." className='   h-40   w-36' name = {item.id} onClick={image}/>
</Link>
    
      </div>
      <div className=' text-sm flex justify-center'>
     {item.title.substring(0, 20)+"..."}
      </div>

      </div>



    )): ""}
     

    
      

      </div>
     

      </div>
      <div className='content-container   mt-20 bg-white  p-3'>
      <h1 className='text-xl font-bold'>Inspired by your shopping trends</h1>
      <button className=' absolute  mt-16 h-12 border w-8 bg-white' onClick={Left1}>
        <i className='fa fa-chevron-left  text-lg'></i>
      </button>
      <button className=' absolute mt-16  btn1  border' onClick={Right1} >
        <i className='fa fa-chevron-right  text-lg'></i>
      </button>
      <div className='contentcontainer1 overflow-x-auto flex  mt-3'>
      {card?card.map((item)=>(
      <div className=' w-52 ml-9' key = {item.id}>
      <div className='contentcards border   w-48  grid justify-center bg-gray-100'>
      <Link to = '/ShowProduct'> <img src = {item.category.image} alt = "..." className='   h-40   w-36' title ={item.title}  onClick={cards}/>
</Link>
     
      </div>
      <div className=' text-sm flex justify-center'>
     {item.title.substring(0, 20)+"..."}
      </div>

      </div>



    )): ""}
     

    
      

      </div>
     

      </div>
      <div className='content-container   mt-20 bg-white  p-3'>
      <h1 className='text-xl font-bold'>Inspired by your shopping trends</h1>
      <button className=' absolute  mt-16 h-12 border w-8 bg-white' onClick={Left2}>
        <i className='fa fa-chevron-left  text-lg'></i>
      </button>
      <button className=' absolute mt-16  btn1  border' onClick={Right2} >
        <i className='fa fa-chevron-right  text-lg'></i>
      </button>
      <div className='contentcontainer2 overflow-x-auto flex  mt-3'>
      {slide3?slide3.map((items)=>(
      <div className=' w-52 ml-9' key = {items.id}>
      <div className='contentcards border   w-48  grid justify-center bg-gray-100'>
      <Link to = "/ShowProduct"> <img src = {items.images[0]} alt = "..." className='card2  h-40   w-36' title2 ={items.title} />
</Link>
     
      </div>
      <div className=' text-sm flex justify-center'>
     {items.title.substring(0, 20)+"..."}
      </div>

      </div>



    )): ""}
     

    
      

      </div>
     

      </div>
    
        </>
    )
}
export default Content;