import axios from 'axios';
import { useState, useEffect} from 'react';
//import bcrypt from 'bcryptjs';
function Signup(){
  const [password1, setPassword1] = useState("null");
  const [password2, setPassword2] = useState("null");
  

  
  

  const firstpassword = (e)=>{
    
    password = e.target.value;
    setPassword1(e.target.value);

   
    
  }
 
  const Secondpassword = (e)=>{
   
    setPassword2(e.target.value);
    

 
}

        

    const handleOnClick = async (e) => {
      console.log("clicked")
        e.preventDefault();
        
 
 // var passwords = form.password1.value;
  
       
        var  email = form.email.value;
        
        
     //   const hashpassword = bcrypt.hashSync(password, '$2a$10$CwTycUXWue0Thq9StjUM0u');
        var firstname  = form.firstname.value;
        var lastname = form.lastname.value;
        var address = form.address.value;
        var password = form.password.value;
         //   setImageFile(form.image.files[0])
       // console.log(form.image.files[0])
     
     /**   // console.log(imageFile)
        const formData = new FormData();
       //   formData.append('imageFile', imageFile);
          formData.append('Email', email);
          
      
         setFormData(formData);
         console.log(formdata)
      
   

     
      let result1 = await axios.post("http://localhost:5000/register", {formdata});
     */
    console.log(email)
      var body = {
        email: email,
        firstname: firstname,
        lastname: lastname,
        password: password,
        address: address

    }
   // let formData2 = new FormData();
    //formData2.append('email', `${email}`);
    //let result1 = await axios.post("http://localhost:5000/register", {formData});
    axios({
      method: 'post',
      url: 'http://localhost:5000/register', // Replace with your backend API endpoint
      data: body
     
  })
  .then(function (response) {
      // Handle success
      alert("successfully registered");
    
  
  })
  .catch(function (error) {
      // Handle error

      console.log(error);
  });
  /** 
    axios({
        method: 'post',
        url: 'http://localhost:5000/register',
        data: body
    })
    .then(function (response) {
        console.log(response);
    })
    .catch(function (error) {
        console.log(error);
    });
      
    }
    */
       
      
          
         // method: "POST",
          //body: JSON.stringify(data),
         // headers: {
         //   'Content-Type': 'application/json'
         // },
         
        
  }
      

    
    
    return(
     
        <>
    <div className = " modal   signup   ">
    <div className="form_wrapper  bg-sky-300 ">
    <div className="form_container">
      <div className="title_container">
        <h2> Registration Form</h2>
      </div>
      <div className='output'></div>
      <div className="row clearfix">
        <div className="">
          <form name = "form">
            <div className="input_field">
              {" "}
              <span>
                <i aria-hidden="true" className="fa fa-envelope" />
              </span>
              <input
                type="email"
                name="email"
                placeholder="Email"
                required
              />
            </div>
            <div className="input_field">
              {" "}
              <span>
                <i aria-hidden="true" className="fa fa-lock" />
              </span>
              <input
                type="password"
                name="password"
                placeholder="Password"
                required
                onChange={firstpassword}
              />
            </div>
            <div className="input_field">
              {" "}
              <span>
                <i aria-hidden="true" className="fa fa-lock" />
              </span>
              <input
                type="password"
                name="password1"
                placeholder="Re-type Password"
                required
                onChange={Secondpassword}
              />
            </div>
            <div className="row clearfix">
              <div className="col_half">
                <div className="input_field">
                  {" "}
                  <span>
                    <i aria-hidden="true" className="fa fa-user" />
                  </span>
                  <input type="text" name="firstname" placeholder="First Name" required />
                </div>
              </div>
              <div className="col_half">
                <div className="input_field">
                  {" "}
                  <span>
                    <i aria-hidden="true" className="fa fa-user" />
                  </span>
                  <input
                    type="text"
                    name="lastname"
                    placeholder="Last Name"
                    required
                  />
                </div>
              </div>
            </div>
            
            <div className="input_field select_option">
            <div className="input_field">
                  {" "}
                  <span>
                    <i aria-hidden="true" className="fa fa-home" />
                  </span>
                  <input
                    type="text"
                    name="address"
                    placeholder="Address"
                    required
                  />
                </div>
            
            </div>
            
              <input type= 'radio'/>
              <label htmlFor="cb1">I agree with terms and conditions</label>
           
           
          </form>
          <button type = "submit" className= "w-full bg-blue-500 h-9 rounded-xl flex justify-center items-center font-bold text-white text-xl" onClick = {handleOnClick}>Register</button>
          
        </div>
      </div>
    </div>
  </div>
 

    </div>
 
</>

    )

}
export default Signup;
