import axios from "axios"; 
import { useNavigate } from "react-router-dom";
function Signin(){
  const navigate = useNavigate();
    const SignIn =async(e)=>{
        e.preventDefault();
        console.log("clicked")

        let form = document.forms['signin-form'];
        let email = form.email.value;
        let password = form.password.value;
        console.log(email)
        var body = {
            email: email,
            password: password,
          
    
        }
       // let formData2 = new FormData();
        //formData2.append('email', `${email}`);
        let result1 = await axios.post("http://localhost:5000/signin", body)
        .then(function (response) {
            // Handle success
            alert(response.data.success);
         //   localStorage.setItem("user_id", response.data);
          //  setUser_Id(response.data);
          if(response.data.email == email){
            localStorage.setItem("user_id", response.data.email);

          }
          if(response.data.success){
           // window.location.reload();
        
           navigate('/Dashboard');
          
          }
          
          
        
        })
        .catch(function (error) {
            // Handle error
      
            console.log(error);
        });

    }
    return(
        <>
         <div className = " modal   signin   h-60  w-96 ml-96 mt-28">
    <div className="form_wrapper  bg-sky-300 h-60 w-96  ">
    <div className="form_container">
      <div className="title_container">
        <h2> Signin Form</h2>
      </div>
      <div className='output'></div>
      <div className="row clearfix">
        <div className="">
          <form name = "signin-form">
            <div className="input_field   w-72">
              {" "}
              <span>
                <i aria-hidden="true" className="fa fa-envelope" />
              </span>
              <input
                type="email"
                name="email"
                placeholder="Email"
                required
                className=" w-60"
              />
            </div>
            <div className="input_field   w-72">
              {" "}
              <span>
                <i aria-hidden="true" className="fa fa-lock" />
              </span>
              <input
                type="password"
                name="password"
                placeholder="Password"
                required
               
              />
            </div>
          
             
           
           
          </form>
          <button type = "submit" className= "w-72 bg-blue-500 h-9 rounded-xl flex justify-center items-center font-bold text-white text-xl" onClick={SignIn}>Login</button>
          
        </div>
      </div>
    </div>
  </div>
 

    </div>


        </>
    )

}
export default Signin;