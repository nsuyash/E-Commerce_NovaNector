import { Link, useNavigate } from "react-router-dom";

function Profile({modal, signup, signin, user}){
   



   

const navigate = useNavigate();
const logout =()=>{
    localStorage.removeItem("user_id");
    navigate("/");

}
   
   
    return(
       
        <>
        <div className="profile w-48 h-56 border p-3 bg-white modal " onMouseLeave={modal}>
        <div className="flex justify-center">{user}</div>
        <button className="  mt-6 h-7  rounded-xl w-full text-white bg-blue-600"><Link to = "/Dashboard">My Profile</Link></button>
        <div className=" mt-3 flex justify-center  border-b">
            <i className="fa fa-user text-xl text-gray-500"></i> <span className="ml-3 text-gray-500 font-bold" onClick={signup}>Sign up</span>
        </div>
        <div className=" mt-3 flex justify-center border-b">
        
        <div className="sign-in  hidden" >
        <i className="fa fa-sign-in text-xl text-gray-500"></i> <span className="ml-3 text-gray-500 font-bold" onClick={signin}>signin</span>
    
       
        </div>
        <div className="logout hidden">
        <i className="fa fa-sign-in text-xl text-gray-500"></i> <span className="ml-3 text-gray-500 font-bold" onClick={logout}>logout</span>
        </div>
        
       
        
       
        </div>
     
            
      
        <div className=" mt-3 flex justify-center border-b">
        <span className="ml-3 text-gray-500 font-bold">My Favourates</span>

        </div>





        </div>

        </>
    )

}
export default Profile;