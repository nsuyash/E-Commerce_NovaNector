import { useEffect, useState } from 'react';
import axios from 'axios';
import bg1 from './pictures/bg1.jpg';
import bg2 from './pictures/bg2.jpg';

import Cards from './elements/Cards';
import './App.css'

import Content from './elements/Content';
import Profile from './elements/Profile';
function Main({productdata, data, image, cards}){
  
 
  
 
    return(
   
        <>
        
     
      
      <div>
      <div className='   absolute   mt-72 z-10  w-full '>
      {<Cards productdata = {productdata}/>}
         
         </div>
      <div id="carouselExample" className="carousel slide ">
    
    <div className="carousel-inner h-96">
   
    
      <div className="carousel-item active">
        <img src={bg1} className="d-block w-100" alt="..." />
      </div>
      <div className="carousel-item">
        <img src={bg2} className="d-block w-100" alt="..." />
      </div>
      <div className="carousel-item">
        <img src="..." className="d-block w-100" alt="..." />
      </div>
    </div>
    <button
      className="carousel-control-prev"
      type="button"
      data-bs-target="#carouselExample"
      data-bs-slide="prev"
    >
      <span className="carousel-control-prev-icon" aria-hidden="true" />
      <span className="visually-hidden">Previous</span>
    </button>
    <button
      className="carousel-control-next"
      type="button"
      data-bs-target="#carouselExample"
      data-bs-slide="next"
    >
      <span className="carousel-control-next-icon" aria-hidden="true" />
      <span className="visually-hidden">Next</span>
    </button>
   
          </div>
       
          
      </div>
   
     <Content deals = {data} image = {image} cards = {cards} />
    
       </>
        
       
    )
}
export default Main;