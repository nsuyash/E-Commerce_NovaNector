import Axios from 'axios';
import { useEffect, useState } from 'react';

function Index(){
    const [data1, setData1] = useState();
    const [filter1, setFilter1] = useState();
    
    useEffect( async()=>{
      let result1 = await Axios.post("http://localhost:5000/Data").then((response)=>{
        console.log(response.data);
        setData1(response.data);
        console.log(data1);
      

    })
    }, [])
         
       
    
     //  let array = data1?data1.map((element)=>(
     //   [element.sector, element.intensity]

   //   )):'';
      console.log(data1);
    google.charts.load("current", {packages:["corechart"]});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ["data", "Intensity", { role: "style" } ],
        [data1[1].sector, data1[1].intensity, 'yellow'],
        [data1[5].sector, data1[2].intensity, 'green'],
        [data1[10].sector, data1[10].intensity, 'blue'],
        [data1[11].sector, data1[11].intensity, 'skyblue'],
        [data1[5].sector, data1[5].intensity, 'green'],
        [data1[19].sector, data1[19].intensity, 'orange'],
        [data1[20].sector, data1[20].intensity, 'cyan'],
        [data1[36].sector, data1[36].intensity, 'purple'],
       
       
        
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: " number of insights grouped by sector",
        width: 600,
        height: 250,
        bar: {groupWidth: "55%"},
        legend: { position: "none" },
      };
      var chart = new google.visualization.BarChart(document.getElementById("barchart_values"));
      chart.draw(view, options);
   
    }
    let filters1 = async(e)=>{
      let data = e.target.value;
      var body = {
        data: data,
       

    }
   // let formData2 = new FormData();
    //formData2.append('email', `${email}`);
    let result1 = await Axios.post("http://localhost:5000/Filter1", body)
    .then(function (response) {
        setFilter1(response.data)
      
      
    
    })
    .catch(function (error) {
        // Handle error
  
        console.log(error);
    });
    }
    
   



   
    return(
        <>
        
          
         <div id="barchart_values"  className= 'flex justify-center border'style={{width: 900, height: 300}}></div>
         <div className=' border flex justify-center'>
         <h1>filter by sector</h1>
          <select placeholder = "filter by sector"  onChange={filters1}>
            <option value= ' Aerospace & defence'>
             Aerospace & defence

            </option>
            <option value='Support Services'>
           Support Services
            </option>
            <option value=' Energy'>
       eneregy

            </option>
            <option value=' Retail'>
            Retail

            </option>
            <option value='Environment'>
            Environment

            </option>
            <option value='Manufacturing'>
            Manufacturing
            </option>
            <option value='demand'>
            demand

            </option>
          </select>
         </div>
        
        
        
        </>
    )
}
export default Index;