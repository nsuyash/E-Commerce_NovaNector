import { useState, useEffect } from "react";
import '../Components/main.css'

function ShowProduct({title, title1}){
   const [product, setProduct] = useState();
   const [num, setNum] = useState();

if(title == 0){
   title = "qjakja";
}
console.log(title);
  
   useEffect(()=>{
      fetch(`https://fakestoreapi.com/products/${title}`)
      .then(res=>res.json())
      .then((data)=>{
       setProduct(data)
       console.log(data)
       console.log(product)
       
        });

   },[title])
   
   const btn = ()=>{
    document.querySelector('.icon').scrollLeft =+ 50;
    document.querySelector('.right').style.display = "block";
    document.querySelector('.left').style.display = "none";
   }
   const btn1 =()=>{ 
    document.querySelector('.icon').scrollLeft =- 100;
    document.querySelector('.right').style.display = "none";
    document.querySelector('.left').style.display = "block";


    
    

   }
   
   function img(){
      setNum(0)
      console.log(num)
   }
   function img2(){
      setNum(1)
      console.log(num)
   }
   function img3(){
      setNum(2)
      console.log(num)
   }
    return(
        <>
           {product?
            <div className=" mt-11 flex">
            <div className=" w-16">
           



           
              
            </div>
            <div className="image h-1/5 w-96 ml-7 bg-gray-200 flex justify-center">
            <img src = {product.image} className="w-96" alt = "..."/>

             </div>
            <div className=" ml-9 bg-white p-3">
           <div className="title text-2xl  ">
           {product.title}

             </div>
            
          <div className="price  mt-5">
        <p className="text-2xl"><i className="fa fa-inr"></i>{product.price}</p>
           <div>inclusive all taxes</div>
           </div>
           <div className="flex icon h-24 items-center p-3 border-t-2 border-b-2">
           <div className="grid justify-center items-center  ml-6 ">
           <i className="fa fa-exchange rounded-circle flex justify-center items-center  w-12 h-12 border  bg-grey-300"></i>
           <div className="flex justify-center  to-blue-600 text-blue-600 text-sm">10 day exchange</div>

           </div>
           <div className="grid justify-center items-center   ml-6">
           <i className="fa fa-truck rounded-circle flex justify-center items-center  w-12 h-12 border  bg-grey-300"></i>
           <div className="flex justify-center to-blue-600 text-blue-600 text-sm">free Delevery</div>

           </div>
           <div className="grid justify-center items-center  ml-6">
           <i className="fa fa-trophy rounded-circle flex justify-center items-center  w-12 h-12 border  bg-grey-300"></i>
           <div className="flex justify-center  to-blue-600 text-blue-600 text-sm">Top brands</div>

           </div>
           <div className="grid justify-center items-center  ml-6">
           <i className="fa fa-truck rounded-circle flex justify-center items-center  w-12 h-12 border  bg-grey-300"></i>
           <div className="flex justify-center  to-blue-600 text-blue-600 text-sm">amazon exchange</div>

           </div>
           <div className="grid justify-center items-center   ml-6">
           <i className="fa fa-lock rounded-circle flex justify-center items-center  w-12 h-12 border bg-grey-300"></i>
           <div className="flex justify-center  to-blue-600 text-blue-600 text-sm">secure transaction</div>

           </div>
           <button className=" right absolute bg-grey-300 hidden " onClick={btn1}><i className="fa fa-angle-left"></i></button>
           <button className=" left absolute bg-grey-300" onClick={btn}><i className="fa fa-angle-right"></i></button>
           
           </div>
           <div className=" w-96 mt-3">
               <h5 className="text-xl font-bold">Product Detail</h5>
               <p>{product.description}</p>

               </div>

             </div>
             <div className=" ml-28 border w-72 bg-white p-3">
             <div>
             <p className="text-2xl"><i className="fa fa-inr"></i>{product.price}</p>
             </div>
             <div className="mt-3 text-blue-600">
               free Delivery
             </div>
             <div className="mt-3">
               <i className="fa fa-map-marker mr-3"></i>Delivery to shgs -hbssns 4625162
             </div>
             <div className="mt-3">
               <div className=" text-sm text-green-600 ">In Stock</div>
             <span>Quantity:</span> <select aria-placeholder="1" className="border">
              <option value={1}>1</option>
              <option value={2}>2</option>
              <option value={3}>3</option>
               <option value={4}>4</option>
               <option value={5}>5</option>
               <option value={6}>6</option>
               <option value={7}>7</option>
               <option value={8}>8</option>
               <option value={9}>9</option>
               <option value={10}>10</option>
               <option value={11}>11</option>
               <option value={12}>12</option>
               <option value={13}>13</option>





              </select>
             </div>
             <button className="  h-9 rounded-xl  w-64 bg-yellow-300 mt-6">Add to Cart</button>
             <button className="  h-9 rounded-xl  w-64 bg-orange-300 mt-6">Buy Now</button>

             </div>
            </div>

           
           :""
            
            }
            
            

          


      
    
        
        

        </>
    )
}
export default ShowProduct;