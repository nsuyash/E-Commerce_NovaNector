import {Link} from 'react-router-dom';
import './App.css';

function Navbar({profile, submit}){
   
 

   
   
    

    return(
        <>
            <div className="navbar  h-20 flex items-center bg-indigo-300 shadow-sm hover:shadow-lg sticky-top">
           
            <ul className="navbar-list   ml-20  flex items-center">
          
            <li className="logo float-left font-bold text-lg">
            <Link to="/" className="list-item ">
            sddse

            </Link>
          

            </li>
            <li className="navbar-item float-left ml-16 text-lg text-white">
            <a href="/">
            <i className="fa fa-map-marker mr-3"></i>Deliver to sdsfd

            </a>


            </li>
           
            <li className="navbar-item float-left ml-16 text-lg  flex items-center  bg-orange-300  rounded-tl-md rounded-bl-md">
           <form name = "form">
           <input className="search-from w-96  h-9 rounded-tl-md rounded-bl-md" placeholder="search what you want"  name = "product" onChange={submit}/>
          </form>
           <span className=" w-9 h-9  flex justify-center  bg-orange-300"><Link to ="/Data"><i className="fa fa-search text-2xl text-gray-500 h-9 " ></i></Link></span>
 
            </li>
            <li className="navbar-item float-left ml-16 text-lg">
             <a href="/" className=" text-white  font-bold text-base  flex" onMouseOver={profile}>
                Account and List <span className="flex items-end ml-1"><i className="fa fa-caret-down "></i></span>
             </a>

            </li>
            <li className="navbar-item float-left ml-16 text-lg">
             <a href="/" className=" text-white  font-bold text-base  flex">
               <i className = "fa fa-shopping-cart text-3xl"></i><span className=" flex items-end">Cart</span>
             </a>

            </li>
        </ul>
        
        </div>
        </>
    )

}
export default Navbar;